B&M Commercial CRM — Elementor Global Kit (v2003e, Enterprise Funnels)

Includes:
- Homepage with dual CTAs (Shay + Rehab), Service Area, Testimonials
- Popups: Quote Intake (Shay) + Rehab & Restoration Intake
- Actions: Email → info@bmcs365.com, Webhook → https://api.bmcs365.com/intake
- Thank You redirect page (2s) with enterprise copy
- Animated header/footer and global styles

Import:
1) Elementor → Site Settings → Import/Export Kit → Import → select bm-global-kit.json.
2) Set Homepage as Front Page (Settings → Reading).
3) Theme Builder → assign Header & Footer to Entire Site.
4) Replace /assets/hero-bm.jpg with your real hero image.
5) Optional: Edit popups to adjust fields/actions.

Testing:
- Submit either popup; you should receive an email at info@bmcs365.com.
- Your API will receive POST JSON at https://api.bmcs365.com/intake.
- Thank You page will auto-redirect to Shay with proper intent.
